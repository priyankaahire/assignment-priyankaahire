1.Open a Questin-2 folder for Second question in assignment.
2.Run Handshakes.java file.
3.After run enter a valid Inupt for expected output.

