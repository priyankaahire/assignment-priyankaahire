public class Handshakes {

	public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        int T, N, total;
        T = in.nextInt();
        
        
       for(int i=0;i<T;i++)
        {
           
            N = in.nextInt();
            total = (N * (N - 1)) / 2;
            //System.out.println("Total Number of Handshekes:");
            System.out.println(total);

           
        }
    }

}