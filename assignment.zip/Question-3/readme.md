1.Open a Questin-3 folder for Third question in assignment.
2.In views folder, 
   1.marker_map.html file
   2.marker_map_db.php file (Database connection)
   3.marker_map_generate.php file
3. In sql folder,
    maps_db.sql file.

Steps:
1.First create a database in your machine, using maps_db.sql file.import this file in your mysql server.
2.After creating database chnage in your views->marker_map_db.php username,password and databasename for connection.
3.After connecting with database run a marker_map.html in you browser.



