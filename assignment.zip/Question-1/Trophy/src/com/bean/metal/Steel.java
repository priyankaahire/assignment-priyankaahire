package com.bean.metal;

import com.bean.Metal;

public class Steel implements Metal{

	@Override
	public float getPurity(float purity) {
		return purity;
	}

}
