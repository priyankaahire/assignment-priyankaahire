package com.bean.metal;

import com.bean.Metal;

public class Aluminim implements Metal{

	@Override
	public float getPurity(float purity) {
		return purity;
	}

}
