package com.bean.abtractfact;

import com.bean.*;
import com.bean.shape.*;

public class ShapeFactory extends AbstractFactory {

	@Override
	public Coating getCoating(String coating) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Metal getMetal(String metal) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shape getShape(String shape) {
		if(shape == null){
	         return null;
	      }		
	      
	      if(shape.equalsIgnoreCase("CUBE")){
	         return new Cube();
	         
	      }else if(shape.equalsIgnoreCase("CYLENDER")){
	         return new Cylender();
	         
	      }else if(shape.equalsIgnoreCase("SPHARE")){
	         return new Sphare();
	      }
	      
	      return null;
	}

}
