package com.bean.abtractfact;

import com.bean.*;

import com.bean.metal.*;

public class MetalFactory extends AbstractFactory {

	@Override
	public Coating getCoating(String coating) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Metal getMetal(String metal) {
		if(metal == null){
	         return null;
	      }		
	      
	      if(metal.equalsIgnoreCase("ALUMINIUM")){
	         return new Aluminim();
	         
	      }else if(metal.equalsIgnoreCase("COPPER")){
	         return new Copper();
	         
	      }else if(metal.equalsIgnoreCase("STEEL")){
	         return new Steel();
	      }
	      
	      return null;
	}

	@Override
	public Shape getShape(String shape) {
		// TODO Auto-generated method stub
		return null;
	}

}
