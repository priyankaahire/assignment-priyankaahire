package com.bean.abtractfact;

import com.bean.*;
import com.bean.coating.*;

public class CoatingFactory extends AbstractFactory {

	@Override
	public Coating getCoating(String coating) {
		if(coating == null){
	         return null;
	      }		
	      
	      if(coating.equalsIgnoreCase("BRONZE")){
	         return new Bronze();
	         
	      }else if(coating.equalsIgnoreCase("GOLD")){
	         return new Gold();
	         
	      }else if(coating.equalsIgnoreCase("SILVER")){
	         return new Silver();
	      }
	      
	      return null;
	}

	@Override
	public Metal getMetal(String metal) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shape getShape(String shape) {
		// TODO Auto-generated method stub
		return null;
	}

}
