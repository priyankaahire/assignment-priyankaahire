package com.bean.abtractfact;

import com.bean.*;

public abstract class AbstractFactory {
	public abstract Coating getCoating(String coating);
	public abstract Metal getMetal(String metal) ;
	public abstract Shape getShape(String shape) ;
}
