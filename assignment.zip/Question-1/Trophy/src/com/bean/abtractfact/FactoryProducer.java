package com.bean.abtractfact;

public class FactoryProducer {
	
	
	public static AbstractFactory getFactory(String choice){
		   
	      if(choice.equalsIgnoreCase("COATING")){
	         return new CoatingFactory();
	         
	      }else if(choice.equalsIgnoreCase("METAL")){
	         return new MetalFactory();
	         
	      }else if(choice.equalsIgnoreCase("SHAPE")){
		         return new ShapeFactory();
		  }
	      
	      return null;
	   }

}
