package com.bean;

public interface Coating {
	float getThickness(float thickness);
}
