package com.bean.coating;

import com.bean.Coating;

public class Silver implements Coating {

	@Override
	public float getThickness(float thickness) {
		return thickness;
	}
	
}

