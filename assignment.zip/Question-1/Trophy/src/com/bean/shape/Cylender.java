package com.bean.shape;

import com.bean.Shape;

public class Cylender implements Shape {

	@Override
	public float getDimensions(float dimension) {
		return dimension;
	}

}