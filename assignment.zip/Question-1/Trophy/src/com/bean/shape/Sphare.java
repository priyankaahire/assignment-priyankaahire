package com.bean.shape;

import com.bean.Shape;

public class Sphare implements Shape {

	@Override
	public float getDimensions(float dimension) {
		return dimension;
	}

}