package com.bean;

public interface Shape {
	float getDimensions(float dimension);
}
