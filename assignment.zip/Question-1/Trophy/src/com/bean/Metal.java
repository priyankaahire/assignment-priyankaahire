package com.bean;

public interface Metal {
	float getPurity(float purity);
}
