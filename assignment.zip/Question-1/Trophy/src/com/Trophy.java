package com;

import java.util.Scanner;

import com.bean.Coating;
import com.bean.Metal;
import com.bean.Shape;
import com.bean.abtractfact.*;

public class Trophy {
	
	public static void displayDetails(String coatingVal,String metalVal,String shapeVal,float coatingThickness,float metalPercnetage,float shapeDimension ){
		//get COATING
	    AbstractFactory coatingFactory = FactoryProducer.getFactory("COATING");
	    Coating coating=coatingFactory.getCoating(coatingVal);
	    
	    System.out.println(coatingVal.toUpperCase()+" Coating Thickness : "+coating.getThickness(coatingThickness));
	    
	    
	  //get METAL
	    AbstractFactory metalFactory = FactoryProducer.getFactory("METAL");
	    Metal metal=metalFactory.getMetal(metalVal);
	    System.out.println(metalVal.toUpperCase()+" Metal percentage: "+metal.getPurity(metalPercnetage));
	    
		//get SHAPE
	    AbstractFactory shapeFactory = FactoryProducer.getFactory("SHAPE");
	    Shape shape=shapeFactory.getShape(shapeVal);
	    System.out.println(shapeVal.toUpperCase()+" Shape Dimension: "+shape.getDimensions(shapeDimension));
	}

	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Coating: ");
		String coating=scanner.next();
		System.out.println("Enter Metal: ");
		String metal=scanner.next();
		System.out.println("Enter Shape: ");
		String shape=scanner.next();
		System.out.println("Enter coating Thickness: ");
		float coatingThickness=scanner.nextFloat();
		System.out.println("Enter metal Percnetage: ");
		float metalPercnetage=scanner.nextFloat();
		System.out.println("Enter shape Dimension: ");
		float shapeDimension=scanner.nextFloat();
		
		Trophy.displayDetails(coating,metal,shape,coatingThickness,metalPercnetage,shapeDimension );
		

	}

}
