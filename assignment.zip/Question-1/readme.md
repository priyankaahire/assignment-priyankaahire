1.Open a Questin-1 folder for First question of assignment.
2.Run Trophy.java file.
3.After run enter a valid Inupt for expected output.

Note:For the first question I am using abtractFactory for the solution.
